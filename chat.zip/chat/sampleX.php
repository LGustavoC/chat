<?php
$host="localhost";
$user="root";
$pass="password";
$db="chat";
$conexao=mysql_connect($host,$user,$pass) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());
?>

<?php

session_start();
$sql=mysql_query("SELECT nome FROM usuarios WHERE email LIKE '%".$_SESSION["email"]."%'");
$linha=mysql_fetch_array($sql);
$nome=$linha['nome'];
$_SESSION['username']=$nome;
if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
    echo "<center><h1>Você tem de estar logado para acessar essa área</h1></center>";
    header("Location: http://localhost/chat/register/login.php");
    exit;
} else{
    echo "<center><h1>Bem vindo $nome!</h1></center>";
}

?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/loose.dtd" >

<html>
<head>
<title>Chat</title>


<style>
body {
	background-color: #eeeeee;
	padding:0;
	margin:0 auto;
	font-family:"Lucida Grande",Verdana,Arial,"Bitstream Vera Sans",sans-serif;
	font-size:11px;
}
</style>

<link type="text/css" rel="stylesheet" media="all" href="css/chat.css" />
<link type="text/css" rel="stylesheet" media="all" href="css/screen.css" />
    <link type="text/css" rel="stylesheet" media="all" href="css/login.css">

<!--[if lte IE 7]>
    <link type="text/css" rel="stylesheet" media="all" href="css/screen_ie.css"/>
    <![endif]-->

</head>
<body>
<div id="main_container">

    <form action="http://localhost/chat/busca/results.php" name ="results1" method="POST">
        <center><input type="text" name="nome"></center>
        <center><input type="submit" name="button" value="Listar Usuário"></center>
    </form>
    <?php
    $sql=mysql_query("SELECT * FROM usuarios");
    $row=mysql_num_rows($sql);
    if($row>0){
        while($linha=mysql_fetch_array($sql)){
            $nome=$linha['nome'];
            $sobrenome=$linha['sobrenome'];
            $email=$linha['email'];
            echo "<a href=\"javascript:void(0)\" onclick=\"javascript:chatWith('$nome')\">Chat com $nome $sobrenome<a/>";
            echo "<strong> E-mail: </strong>".@$email;
            echo "<br /><br />";
        }
    }
    ?>
    <form action="http://localhost/chat/busca/buscacompleta.php" name ="results2" method="POST">
        <center><input type="submit" name="button" value="Listar Todos os Usuários"></center>
    </form>

    <center><h1><button><a href="http://localhost/chat/register/logout.php">Sair</a></button></h1></center>
<!-- YOUR BODY HERE -->

</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/chat.js"></script>

</body>
</html>