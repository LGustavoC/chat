<html>
    <head>
        <title>Resultados da Busca</title>
    </head>
    <body>
        <?php
            $host="localhost";
            $user="root";
            $pass="password";
            $db="chat";
            $conexao=mysql_connect($host,$user,$pass) or die(mysql_error());
            mysql_select_db($db) or die(mysql_error());
        ?>

        <?php
            $buscar=$_POST['nome'];
            $sql=mysql_query("SELECT * FROM usuarios WHERE nome LIKE '%".$buscar."%'");
            $row=mysql_num_rows($sql);
            if($row>0){
                while($linha=mysql_fetch_array($sql)){
                    $nome=$linha['nome'];
                    $sobrenome=$linha['sobrenome'];
                    $email=$linha['email'];
                    echo "<strong>Nome: </strong>";
                    echo "<a href=\"http://localhost/chat/sampleX.php\">$nome<a/>";
                    echo "<br /> <br />";
                    echo "<strong>Sobrenome: </strong>".@$sobrenome;
                    echo "<br /><br />";
                    echo "<strong>E-mail: </strong>".@$email;
                    echo "<br /><br />";
                    echo "<br /><br />";
                }
                return true;
            } else{
                echo "Desculpe, nenhum usuário com esse nome foi encontrado";
                return false;
            }
        ?>
    </body>
</html>