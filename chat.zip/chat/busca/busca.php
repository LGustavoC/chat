<html>
    <head>
        <title>Busca</title>
    </head>
    <body>
        <form name="searchform" method="post" action="results.php">
            Buscar usuários: <input type="text" name="buscar"/><input type="submit" value="Ir"/>
        </form>
    </body>
</html>