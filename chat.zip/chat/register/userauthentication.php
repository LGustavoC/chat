<?php
    $host="localhost";
    $user="root";
    $pass="password";
    $db="chat";
    $conexao=mysql_connect($host,$user,$pass) or die(mysql_error());
    mysql_select_db($db) or die(mysql_error());
?>

<html>
    <head>
        <title>Autenticando</title>
        <script type="text/javascript">
            function loginsuccessfully(){
                setTimeout("window.location='http://localhost/chat/sampleX.php'",3000);
            }

            function loginfailed(){
                setTimeout("window.location='login.php'",3000);
            }
        </script>
    </head>
    <body>
        <?php
            $email=$_POST['email'];
            $senha=$_POST['senha'];
            $sql=mysql_query("SELECT * FROM usuarios WHERE email='$email' and senha='$senha'") or die(mysql_error());
            $row=mysql_num_rows($sql);
            if($row>0){
                session_start();
                $_SESSION['email']=$_POST['email'];
                $_SESSION['senha']=$_POST['senha'];
                echo "<center><h1>Logado com Sucesso</h1></center>";
                echo "<script>loginsuccessfully()</script>";
            }
            else{
                echo "<center><h1>Nome de usuario ou senha invalidos</h1></center>";
                echo "<script>loginfailed()</script>";
            }
        ?>
    </body>
</html>
