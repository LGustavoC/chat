<?php
    $host="localhost";
    $user="root";
    $pass="password";
    $db="chat";
    $conexao=mysql_connect($host,$user,$pass) or die(mysql_error());
    mysql_select_db($db) or die(mysql_error());
    ?>

<?php
    session_start();
    if(!isset($_SESSION["email"]) || !isset($_SESSION["senha"])){
        echo "<center><h1>Você tem de estar logado para acessar essa área</h1></center>";
        header("Location: login.php");
        exit;
    } else{
        echo $_SESSION["email"];
        echo "<center><h1>Você está logado!</h1></center>";
        echo "<center><h1>Bem vindo </h1></center>".$_SESSION['nome'];

    }
?>

<html>
    <head>
        <title>Painel</title>
    </head>
    <body>
    </br>
    <center><h1><button><a href="logout.php">Sair</a></button></h1></center>
    </body>
</html>