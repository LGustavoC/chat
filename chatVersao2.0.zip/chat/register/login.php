<html>
    <head>
        <title>Sistema de Login</title>
    </head>

    <body>
        <form name="loginform" method="post" action="userauthentication.php">
            E-mail: <input type="text" name="email"/></br>
            Senha: <input type="password" name="senha"/></br>
            <input type="submit" value="login"/>
        </form>
        <button><a href="cadastro">Cadastrar-se</a></button>
    </body>

</html>