<html>
    <head>
        <title>Cadastrando</title>
        <script type="text/javascript">
            function cadastro(){
                setTimeout("window.location='login.php'",3000);
            }
        </script>
    </head>
    <body>
        <?php
        //Estabelecendo conexão
        $host="localhost";
        $user="root";
        $pass="password";
        $db="chat";
        $conection=mysql_connect($host,$user,$pass) or die(mysql_error());
        mysql_select_db($db) or die(mysql_error());
        ?>

        <?php
        //Inserindo os dados no banco de dados
        $nome=$_POST['nome'];
        $sobrenome=$_POST['sobrenome'];
        $email=$_POST['email'];
        $senha=$_POST['senha'];
        $sql=mysql_query("INSERT INTO usuarios(nome,sobrenome,email,senha)
        VALUES('$nome','$sobrenome','$email','$senha')");
        echo "<center><h1>Cadastro efetuado com sucesso!</h1></center>";
        echo "<script>cadastro()</script>";
        ?>
    </body>
</html>
